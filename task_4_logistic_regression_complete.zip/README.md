# Logistic Regression Binary Classifier - Breast Cancer Dataset

## Objective
To build a binary classification model using logistic regression to predict breast cancer malignancy.

## Dataset
Breast Cancer Wisconsin Dataset  
Source: https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data

## Tools Used
- Python
- Scikit-learn
- Pandas, Matplotlib, Seaborn

## Evaluation Metrics
- Confusion Matrix
- Precision
- Recall
- ROC-AUC Score
- Sigmoid Function Plot

## Instructions to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run script: `python src/logistic_regression_model.py`
3. Check outputs in the `results/` folder